import react,{Component} from "react";

const Information = [
  {
    "name":"github",
    "value":"profile"
  },
  {
    "name":"github",
    "value":"search"
  },
  {
    "name":"github",
    "value":"repo new"
  },
  {
    "name":"github",
    "value":"repo pr list"
  },
  {
    "name":"github",
    "value":"repo pr"
  },
  {
    "name":"github",
    "value":"repo issues list"
  },
  {
    "name":"github",
    "value":"repo issues"
  },
  {
    "name":"github",
    "value":"repo"
  },
  {
    "name":"github",
    "value":"login"
  },
  {
    "name":"github",
    "value":"logout"
  }
];

export default Information;
